DROP TABLE `#__hikashop_payment_plg_paylike`;


